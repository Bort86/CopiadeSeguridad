<!DOCTYPE html>
<!--
Necesitamos un programa que haga lo siguiente: 
    Un formulario donde introducir Datos. 
    Controlar los datos de entrada en el cliente
    Validar los datos en el servidor
    ErrorCheck
    Modular
    Responsabilidades?
    Comentarios
-->
<?php
error_reporting(0);
$vdnaB = "ACAGACAGATACAAT";
$vdnaC = NULL;
$vrna = "ACAGACAGAUACAAU";
    if (filter_has_var(INPUT_POST, "form_dna")){
        $vdnaC = filter_input(INPUT_POST, "in_dna_C");
    }
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>DNA Check Mcodina</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" crossorigin="anonymous"/>        
         <?php 
            require_once 'php/functions.php';
        ?>
    </head>
    <body>
        <form action="<?=HTMLSPECIALCHARS($_SERVER['PHP_SELF'])?>" method="post" enctype="multipart/form-data">
            <br>
             <h2 align="center">Practica 4 - Marc Codina Gomez</h2>
            <div class="container">
                <div class="jumbotron">
                    <input type="text" value="<?=$vdnaB?>" name="in_dna_B" disabled>DNA Base<br>
                    <input type="text" value="<?=$vdnaC?>" name="in_dna_C">DNA Check<br>
                    <input type="submit" value="Send" name="form_dna" >
                    <div id="div_result">
                       <?php
                           if (filter_has_var (INPUT_POST,"form_dna")&&filter_input(INPUT_POST, "in_dna_C")!=NULL){
                               echo "<br>";
                               variantTable ($vdnaB, $vdnaC);
                           }
                       ?>
                   </div>
                </div>
                <div class="jumbotron">
                    <div id="div_result_rna">
                        <input type="text" value="<?=$vrna?>" name="in_rna" disabled>Cadena RNA <br>
                        <h2>Contador:</h2>
                        <?php 
                            sumBase($vrna);
                        ?>
                    </div>
                </div>
            </div>
        </form>
    </body>
</html>
