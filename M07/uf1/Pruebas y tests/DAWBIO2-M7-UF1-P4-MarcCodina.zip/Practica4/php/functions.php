<?php
function printRow (int $pos, string $fall){
    echo "<tr>";
    echo "<td align=\"center\">$pos</td><td align=\"right\">$fall</td>";
    echo"</tr>";
}
/**
 * @param String $dnaBase  Is the reference DNA 
 * @param String $dnaCompare  Is the DNA sequence the user enters. 
 * It's a process that does the following: 
 * First it calls the checkStringDNA and see if the user String is a correct
 * DNA String. 
 * If it is: 
 *      It checks which Strings is bigger.
 *      Then it uses the two Strings and check if they match or not letter by letter. 
 *      Finally calls the printRow function to print one new row every time
 *      something is not in the correct place. 
 * If it's not:
 *      It sends an error message. 
 *  ++
 * @author Mcodina
 */
function variantTable (string $dnaBase, string $dnaCompare){
    if (checkStringDNA($dnaCompare)==true){
        echo "<table border=1>";
        echo "<tr><th align=\"center\">Posicion</th><th align=\"center\">Error</th></tr>";
        if (strlen($dnaBase)< strlen($dnaCompare)){
            for ($i=0;$i<strlen($dnaBase);$i++){
                if ($dnaBase[$i]!=$dnaCompare[$i]){
                    printRow ($i,"Base: $dnaBase[$i] <br>Comp: $dnaCompare[$i] ");    
                }
            }    
        }
        else{
            for ($i=0;$i<strlen($dnaCompare);$i++){
                if ($dnaBase[$i]!=$dnaCompare[$i]){
                    printRow ($i,"Base: $dnaBase[$i] <br>Comp: $dnaCompare[$i] ");    
                }
            }
        }
        echo "</table>";
    }
    else{
        echo "Something went Wrong.";
    }
}
/**
 *@param String $dnaCompare The string that a user has entered. 
 * checkStringDNA checks every single letter of the String and apply a 
 * preg_match on it. 
 * If it contains only ATCG will return True. 
 * If some letter is not one of the nucleic acids will return False. 
 * 
 * @author Mcodina  
 */
function checkStringDNA (string $dnaCompare): bool{
    $result = true;
    for ($i = 0; $i<strlen($dnaCompare);$i++){
        if (preg_match("/[^ATCG]/i", $dnaCompare[$i])){
            return false;
        }
    }
    return $result;
}
/**
 * 
 * @param String $dnaCompare The string that a user has entered. 
 * 
 * SumBase uses an associative Array ($count) to count every nucleic acid. 
 * Every time it checks what letter it contains and sum 1 on that position of the
 * array.
 * Finally will call the printTable function to print the array. 
 * 
 * @example
 * ACA
 * will check A, and put a +1 on the A position of the array. 
 * Then chekc C, and put a +1 on the C position of the array.
 * Finally will check A, and put a secon +1 on the A position of the array.
 * At the end the array will be something like this: 
 *      "A" => 2
 *      "C" => 1
 * @author Mcodina  
 */
function sumBase (string $dnaCompare){
      $count=array ("A" => 0,"U" => 0,"C" => 0,  "G" => 0  );
      for ($i=0;$i<strlen($dnaCompare);$i++){
        if ($dnaCompare[$i]=="A"){
            $count["A"]=$count["A"]+1;
        }
        elseif ($dnaCompare[$i]=="U") {
            $count["U"]=$count["U"]+1;
        }
        elseif ($dnaCompare[$i]=="C") {
            $count["C"]=$count["C"]+1;
        }
        elseif ($dnaCompare[$i]=="G") {
            $count["G"]=$count["G"]+1;
        }
      }
      printaTabla($count);
}

/**
 * @param array $count the array with the Sum of every nucleic acid.
 * Prints a table with the results of the sumBase. 
 * @author Mcodina.  
 */
function printaTabla (array $count){
    echo "<br><table border=1 width=100>"
              . "<tr align='center'>"
              .     "<th >A</th>"
              .     "<th align='center'>U</th><th align='center'>C</th>"
              .     "<th align='center'>G</th></tr><tr><th align='center'>{$count['A']}</th>"
              .     "<th align='center'>{$count['U']}</th><th align='center'>{$count['C']}</th>"
              .     "<th align='center'>{$count['G']}</th>"
              .     "</tr>"
              . "</table>";
}