<?php

/**
 * Function that compares 2 strings given by user
 * @param type $DNA_base 1º operand
 * @param type $DNA_comparar 2º operand
 * @return  chars that are not equal, and their position in the string
 */
function Compare($DNA_base, $DNA_comparar) {

    $resultado = 0;
    $Bigger_DNA = "";

    if ($DNA_base > $DNA_comparar) {
        $Bigger_DNA = $DNA_base;
    } else {
        $Bigger_DNA = $DNA_comparar;
    }

    for ($indice = 0; $indice < strlen($Bigger_DNA); $indice++) {


        if ($DNA_base[$indice] != $DNA_comparar[$indice]) {
            $resultado = $indice + 1;
            echo "La posición " . $resultado . " no es correcta <br>";
            echo $DNA_base[$indice];
            echo " es distinto de ";
            echo $DNA_comparar[$indice];
            echo "<br>";
        }
    }
}

/**
 * functino that counts how many bases has an RNA string
 * @param type $RNA string given by user
 * @return calls a function to print an associative array with the results
 */
function DNA_base_calculator($RNA) {
    $RNA = strtoupper($RNA);

    $contador = array("A" => 0, "U" => 0, "C" => 0, "G" => 0);

    for ($indice = 0; $indice < strlen($RNA); $indice++) {
        if ($RNA[$indice] == "A") {
            $contador["A"] ++;
        }
        if ($RNA[$indice] == "U") {
            $contador["U"] ++;
        }
        if ($RNA[$indice] == "C") {
            $contador["C"] ++;
        }
        if ($RNA[$indice] == "G") {
            $contador["G"] ++;
        }
    }

    Print_contador($contador);
}

/**
 * function that prints an associative array given by another function
 * @param type $contador the associative array with the rNa bases and its counters
 * @return an echo message coded in a table
 */
function Print_contador($contador) {
    echo "<table border=1>";
    echo "<tr>";
    echo "<td> Base A </td>";
    echo "<td>{$contador['A']}</td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td> Base U </td>";
    echo "<td>{$contador['U']}</td>";
    echo "</tr>";
    echo "<tr>";
    echo "<td> Base G </td>";
    echo "<td>{$contador['G']}</td>";
    echo "</tr>";
    echo "<td> Base C </td>";
    echo "<td>{$contador['C']}</td>";
    echo "</tr>";
    echo "</table>";
}

/**
 * function to do validations
 * it confirms wether the introduced dna or rna string is empty and if it has its
 * right bases
 * @param type $DNA a string to validate
 * @param type $pattern defined before, a regex to do a preg_match
 * @return boolean true if its everthing ok and false if it's not
 */
function validate_total($DNA, $pattern) {
    if (check_empty($DNA) == true && validate_adn($DNA, $pattern) == true) {
        return true;
    } return false;
}

/**
 * function to confirm if a string is empty
 * @param type $DNA
 * @return boolean true if its not empy and false if its empty, also prints 
 * an error message
 */
function check_empty($DNA) {
    if ($DNA == NULL) {
        echo "Campo  vacío";
        return false;
    } return true;
}

/**
 * function that validates if a nucleotid acid string has its right bases
 * @param type $DNA a string for DNA or RNA
 * @param type $pattern constats defined before, regex to do a preg-match
 * @return boolean true if its right or false if its not a DNA or RNA;
 * and also prints an echo message with an error
 */
function validate_adn($DNA, $pattern) {
    $contador = 0;
    $resultado = true;
    for ($indice = 0; $indice <= strlen($DNA); $indice++) {
        if (preg_match($pattern, $DNA[$indice])) {
            $contador++;
        }
    }

    if ($contador > 0) {
        echo "Non-ADN or ARN base introduced";
        $resultado = false;
    }
    return $resultado;
}
