<!DOCTYPE html>
<html> 
	<head>
		<meta charset="UTF-8" />
	  <title>Logout</title>
	</head>
	<body>
        <?php
            session_start();
            if (isset($_SESSION["user_valid"])) {  //user valid
                session_destroy();
                echo "<p>Logout done.</p>";
                echo "<p>[<a href='login.php'>Login</a>]</p>";                
            }
            else {  //user not logged yet.
                echo "<p>Not logged!</p>";
                echo "<p>[<a href='login.php'>Login</a>]</p>";                
            }
        ?>
	</body>
</html>