<!DOCTYPE html>
<html lang="en">
	<head>
	   <meta charset="UTF-8">
	   <title>Login</title>
		<link rel="stylesheet" type="text/css" href="css/styles.css" />
	</head>
	<body>
		<form action="login_result.php" method="post">
			<fieldset>
				<legend>Login</legend>
				<label for="user">User:</label>
				<input type="text" id="user" name="user" value="" />
				<label for="password">Password:</label>
				<input type="password" id="password" name="password" value="" />
				<input type="submit" name="submit" value="LOGIN" />
			</fieldset>
		</form>	
	</body>
</html>