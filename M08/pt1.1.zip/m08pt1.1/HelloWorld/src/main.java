public class main {
	public static void main(String [ ] args) {
		SayHelloTo me = new SayHelloTo("You");
		System.out.println(me.helloTo());
	}
}
