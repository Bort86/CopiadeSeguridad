/**
@author: Pablo Rodriguez
*/
public class SayByeTo {

	private String name = "";

	public SayByeTo(String myName) {
		this.name = myName;
	}

	public String ByeTo() {
		return "Bye " + this.name + "!";
	}
}
