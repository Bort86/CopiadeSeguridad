function introduceProperties(){
  var decision = confirm("Do you really want to introduce these properties?");

  if (decision){
    window.open("../popUpWindows/popUpWindow.html",
    "_blank", "width=800px,height=800px");
  }
}
